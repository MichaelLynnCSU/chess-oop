package a1;

public class IllegalMoveException extends Exception {
    public IllegalMoveException(String message){
        super(message);
    }
}

