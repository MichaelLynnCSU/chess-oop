package a1;


public class IllegalPositionException extends Exception {

    public IllegalPositionException(String message){
        super(message);
    }

}
